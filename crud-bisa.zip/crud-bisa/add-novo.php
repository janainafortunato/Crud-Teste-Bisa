<?php 
include 'init.php';

//Pega os dados do formulario
$name = isset($_POST['name']) ? $_POST['name'] : null;

//validação para formulario

if(empty($name)){
	echo "volte e preencha todos os campos";
	exit;
}
//var_dump($name);
//faz a busca no banco de dados
$PDO = db_connect();
$sql =("SELECT name FROM cliente ORDER BY id, name ASC");
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':name', $name);
$stmt->execute();
$clientes = $stmt->fetch(PDO::FETCH_ASSOC);
//var_dump($name);
//echo $name;


//SQL para selecionar os registros
$sql = "SELECT * FROM cliente WHERE name LIKE  %name%";

$stmt = $PDO->prepare($sql);
$stmt->execute();

//$this->db->select('*');
//$this->db->get('cliente')->result();



?>

<!DOCTYPE html>
<html>
<head>
	<title>sistema de pesquisa</title>
</head>
<body>
	<div>
		<table width="50%" border="1">
			<tr>
				<th>Resultado</th>
			</tr>
			<?php foreach ($clientes as $cliente) { ?>
			<?php// var_dump($cliente); die();  ?>
			
				<tr>
					<td><?php echo $cliente ?></td>
				</tr>
			<?php } ?>
				</table> 
		</table>
	</div>
</body>
</html>



