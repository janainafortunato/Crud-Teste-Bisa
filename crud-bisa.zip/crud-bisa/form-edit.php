<?php
require 'init.php';
 
// pega o ID da URL
$id = isset($_GET['id']) ? (int) $_GET['id'] : null;
 
// valida o ID
if (empty($id))
{
    echo "ID para alteração não definido";
    exit;
}
 
// busca os dados do cliente a ser editado
$PDO = db_connect();
$sql = "SELECT name, cpf_cnpj, telefone, endereco FROM cliente WHERE id = :id";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
 
$stmt->execute();
 
$cliente = $stmt->fetch(PDO::FETCH_ASSOC);
 
// se o método fetch() não retornar um array, significa que o ID não corresponde a um usuário válido
if (!is_array($cliente))
{
    echo "Nenhum cliente encontrado";
    exit;
}
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title>Edição de cliente</title>
       
    </head>
 
    <body>
        
        <content>
            <div>
                 <h2>Edição de cliente</h2>
            </div>
        </content>
       
       <content>
           <div>
               <form action="edit.php" method="POST">
                    <label for="name">Nome:
                        <input type="text" name="name" id="name" value="<?php echo $cliente['name'] ?>">
                    </label>
                    <label for="cpf_cnpj">CPF/CNPJ:
                        <input type="number" name="cpf_cnpj" id="cpf_cnpj" value="<?php echo $cliente['cpf_cnpj'] ?>">
                    </label>
                    <label for="telefone">Telefone: 
                        <input type="number" name="telefone" id="telefone" value="<?php echo $cliente['telefone'] ?>">
                    </label>
                    <label for="endereco">Endereço: 
                        <input type="text" name="endereco" id="endereco" value="<?php echo $cliente['endereco'] ?>">
                    </label>
                    <label><input type="hidden" name="id" value="<?php echo $id ?>"></label>
                    <label><input type="submit" value="Alterar"></label>
                </form>
           </div>
       </content>
         

    </body>
</html>