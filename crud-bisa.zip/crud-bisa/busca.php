<?php

require 'init.php';

?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Listagem de Clientes</title>
</head>
<body>
    
           <h1>Listagem de Clientes</h1>
 
            <form action="add-novo.php" method="POST" >
                <label  for="name">Pesquisar</label>
                    <input type="text" name="name" placeholder="Infome o Nome ou E-mail">
                    <input type="submit" value="pesquisar">
            </form>
                <br>
                <a href='index.php'>Ver Todos</a>
         

           <a href='form-add.php'>Volta</a><br>

       
</body>   
</html>