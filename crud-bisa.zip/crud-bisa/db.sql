CREATE DATABASE `bisa`;

USE `bisa`;

CREATE TABLE `cliente`(
`id` INT NOT NULL AUTO_INCREMENT,
`name` VARCHAR(100) NOT NULL,
`cpf_cnpj` INT NOT NULL,
`telefone` INT NOT NULL,
`endereco` VARCHAR(255) NOT NULL,
PRIMARY KEY(`id`)

)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cliente` ( `id` , `name`, `cpf_cnpj`, `telefone`, `endereco`) VALUES ( 1 , 'jana', 37785879001, 32456512, 'Rua Bisa Web');