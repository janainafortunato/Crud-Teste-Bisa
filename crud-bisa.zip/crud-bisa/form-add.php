<?php

require 'init.php';

?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title>Sistema de Clientes</title>
       
       
    </head>
 
    <body>

          <div>
                 <h1>Sistema de Cadastro</h1>
          </div>     
          <div >
              <div>
                   <form action="add.php" method="POST">
                        <label for="name">Nome: </label>
                            <input type="text" name="name" id="name" placeholder="Nome completo">
                     
                        <label for="cpf_cnpj">CPF/CNPJ:</label> 
                            <input type="number" name="cpf_cnpj" id="cpf_cnpj" placeholder="CPF ou CNPJ">
                      
                        <label for="telefone">Telefone:</label>
                            <input type="number" name="telefone" id="telefone" placeholder="Telefone">
                      
                        <label for="endereco">Endereço:</label> 
                            <input type="text" name="endereco" id="endereco" placeholder="Endereço completo">
                        <label><input type="submit" value="Cadastrar"></label>
                    </form>
              </div>
          </div>
      </content>

   
 
    </body>
</html>