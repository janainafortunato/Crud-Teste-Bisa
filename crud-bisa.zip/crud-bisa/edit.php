<?php
 
require_once 'init.php';
 
// resgata os valores do formulário
$name = isset($_POST['name']) ? $_POST['name'] : null;
$cpf_cnpj = isset($_POST['cpf_cnpj']) ? $_POST['cpf_cnpj'] : null;
$telefone = isset($_POST['telefone']) ? $_POST['telefone'] : null;
$endereco = isset($_POST['endereco']) ? $_POST['endereco'] : null;
$id = isset($_POST['id']) ? $_POST['id'] : null;
 
// validação dos dados passado pelo o metodo POST
if (empty($name) || empty($cpf_cnpj) || empty($telefone) || empty($endereco))
{
    echo "Volte e preencha todos os campos";
    exit;
}
 

 
// atualiza o banco
$PDO = db_connect();
$sql = "UPDATE cliente SET name = :name, cpf_cnpj = :cpf_cnpj, telefone = :telefone, endereco = :endereco WHERE id = :id";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':name', $name);
$stmt->bindParam(':cpf_cnpj', $cpf_cnpj);
$stmt->bindParam(':telefone', $telefone);
$stmt->bindParam(':endereco', $endereco);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
 
if ($stmt->execute())
{
    header('Location: index.php');
}
else
{
    echo "Erro ao alterar";
    print_r($stmt->errorInfo());
}

?>