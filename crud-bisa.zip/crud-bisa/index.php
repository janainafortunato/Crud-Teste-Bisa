<?php

require_once 'init.php';
 
// abre a conexão
$PDO = db_connect();
 
// SQL para contar o total de registros
// A biblioteca PDO possui o método rowCount(), mas ele pode ser impreciso.
// É recomendável usar a função COUNT da SQL

$sql_count = "SELECT COUNT(*) AS total FROM cliente ORDER BY id,  name ASC";
 
  // SQL para selecionar os registros
        $sql = "SELECT id, name, cpf_cnpj, telefone, endereco FROM cliente ORDER BY id, name ASC";
 
// conta o total de registros
$stmt_count = $PDO->prepare($sql_count);
$stmt_count->execute();
$total = $stmt_count->fetchColumn();
 
// seleciona os registros
$stmt = $PDO->prepare($sql);
$stmt->execute();
?>

<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title>Lista de clientes</title>
       
    </head>
 
    <body>
         
         
             <div>
                  <h1>Lista de clientes</h1>
             </div>
    
            <div>
                <p><a href="form-add.php">Adicionar Usuário</a></p>
 
                <p>Total de usuários: <?php echo $total ?></p>
 
                <?php if ($total > 0): ?>
            </div>
            
        <div>    
            <table width="50%" border="1">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>CPF/CNPJ</th>
                        <th>Telefone</th>
                        <th>Endereço</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($cliente = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                    <tr>
                        <td><?php echo $cliente['name'] ?></td>
                        <td><?php echo $cliente['cpf_cnpj'] ?></td>
                        <td><?php echo $cliente['telefone'] ?></td>
                        <td><?php echo $cliente['endereco'] ?></td>
                        <td>
                        <a href="form-edit.php?id=<?php echo $cliente['id'] ?>">Editar</a>
                        <a href="delete.php?id=<?php echo $cliente['id'] ?>" onclick="return confirm('Tem certeza de que deseja remover?');">Remover</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
 
        <?php else: ?>
 
        <p>Nenhum cliente registrado</p>
 
        <?php endif; ?>
                </div>
            </div>
        </content>
        
       <content class="">
           <div>
                 <a href="busca.php">Pesquisa de clientes</a>
           </div>
       </content>
      

    </body>
</html>